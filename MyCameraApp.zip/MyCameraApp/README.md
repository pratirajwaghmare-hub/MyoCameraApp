# My Camera App (Java + XML + CameraX)

Open this folder in Android Studio (File > Open) and let Gradle sync.
Run on a physical phone (USB debugging ON) or an AVD with a camera.

- Language: Java, UI: XML
- CameraX 1.3.4, minSdk 23, compileSdk/targetSdk 34
- Photos are saved to Pictures/MyCameraApp via MediaStore
- Debug APK: Build > Build Bundle(s) / APK(s) > Build APK(s)
  (output: app/build/outputs/apk/debug/app-debug.apk)

Android Studio must use JDK 17 (Settings > Build Tools > Gradle > Gradle JDK).

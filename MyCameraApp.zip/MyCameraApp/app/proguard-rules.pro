# Add project specific ProGuard rules here.
# Release minification is disabled by default in this project.

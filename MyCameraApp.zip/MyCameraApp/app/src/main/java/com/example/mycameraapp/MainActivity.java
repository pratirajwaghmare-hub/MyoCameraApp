package com.example.mycameraapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraInfoUnavailableException;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.MeteringPointFactory;
import androidx.camera.core.Preview;
import androidx.camera.core.TorchState;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;
import androidx.exifinterface.media.ExifInterface;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Main (and only) screen of the camera app.
 * Uses CameraX: Preview + ImageCapture bound to this Activity's lifecycle.
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MyCameraApp";
    private static final String APP_FOLDER = "MyCameraApp";   // Pictures/MyCameraApp

    // ---- Views ----
    private PreviewView previewView;
    private ImageButton btnFlash;
    private ImageButton btnSwitchCamera;
    private ImageButton btnCapture;
    private ImageView imgThumbnail;
    private View viewFlashEffect;
    private View layoutMessage;
    private TextView tvMessage;
    private Button btnMessageAction;

    // ---- CameraX ----
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private Preview preview;
    private ImageCapture imageCapture;
    private int lensFacing = CameraSelector.LENS_FACING_BACK;
    private boolean cameraStarting = false;

    // ---- State ----
    private boolean torchEnabled = false;
    private boolean isCapturing = false;
    @Nullable
    private Uri lastPhotoUri;

    private LiveData<Integer> torchStateLiveData;
    private Observer<Integer> torchObserver;

    private ExecutorService backgroundExecutor;
    private OrientationEventListener orientationListener;

    // Registered as a field so it is always registered before the Activity is STARTED.
    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestMultiplePermissions(),
                    result -> onPermissionResult());

    // =====================================================================
    // Lifecycle
    // =====================================================================

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        btnFlash = findViewById(R.id.btnFlash);
        btnSwitchCamera = findViewById(R.id.btnSwitchCamera);
        btnCapture = findViewById(R.id.btnCapture);
        imgThumbnail = findViewById(R.id.imgThumbnail);
        viewFlashEffect = findViewById(R.id.viewFlashEffect);
        layoutMessage = findViewById(R.id.layoutMessage);
        tvMessage = findViewById(R.id.tvMessage);
        btnMessageAction = findViewById(R.id.btnMessageAction);

        backgroundExecutor = Executors.newSingleThreadExecutor();

        btnCapture.setOnClickListener(v -> takePhoto());
        btnSwitchCamera.setOnClickListener(v -> switchCamera());
        btnFlash.setOnClickListener(v -> toggleTorch());
        imgThumbnail.setOnClickListener(v -> openLastPhoto());

        // Tap on the preview = focus there
        previewView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP && camera != null) {
                MeteringPointFactory factory = previewView.getMeteringPointFactory();
                MeteringPoint point = factory.createPoint(event.getX(), event.getY());
                FocusMeteringAction action = new FocusMeteringAction.Builder(point).build();
                camera.getCameraControl().startFocusAndMetering(action);
                v.performClick();
            }
            return true;
        });

        setupOrientationListener();

        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            showMessage(R.string.error_no_camera_hardware, 0, null);
            return;
        }

        if (!hasCameraPermission()) {
            permissionLauncher.launch(requiredPermissions());
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (orientationListener != null && orientationListener.canDetectOrientation()) {
            orientationListener.enable();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            return;
        }
        if (hasCameraPermission()) {
            // Covers: first launch with permission already granted, and returning from Settings.
            if (cameraProvider == null && !cameraStarting) {
                hideMessage();
                startCamera();
            }
            loadLatestPhoto();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (orientationListener != null) {
            orientationListener.disable();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        removeTorchObserver();
        if (cameraProvider != null) {
            cameraProvider.unbindAll();   // release the camera
        }
        camera = null;
        if (backgroundExecutor != null) {
            backgroundExecutor.shutdown();
        }
    }

    // =====================================================================
    // Permissions
    // =====================================================================

    private String[] requiredPermissions() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            return new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
        }
        return new String[]{Manifest.permission.CAMERA};
    }

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** On Android 10+ no storage permission is needed to save our own photos. */
    private boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
            return true;
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void onPermissionResult() {
        if (hasCameraPermission()) {
            hideMessage();
            if (cameraProvider == null && !cameraStarting) {
                startCamera();
            }
            loadLatestPhoto();
            if (!hasStoragePermission()) {
                Toast.makeText(this, R.string.permission_storage_needed, Toast.LENGTH_LONG).show();
            }
        } else {
            boolean canAskAgain = ActivityCompat.shouldShowRequestPermissionRationale(
                    this, Manifest.permission.CAMERA);
            if (canAskAgain) {
                showMessage(R.string.permission_rationale, R.string.grant_permission,
                        v -> permissionLauncher.launch(requiredPermissions()));
            } else {
                showMessage(R.string.permission_denied_settings, R.string.open_settings,
                        v -> openAppSettings());
            }
        }
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", getPackageName(), null));
        startActivity(intent);
    }

    // =====================================================================
    // Camera setup
    // =====================================================================

    private void startCamera() {
        cameraStarting = true;
        final ListenableFuture<ProcessCameraProvider> future =
                ProcessCameraProvider.getInstance(this);

        future.addListener(() -> {
            cameraStarting = false;
            try {
                cameraProvider = future.get();
                bindCameraUseCases();
            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "Camera provider initialisation failed", e);
                cameraProvider = null;
                showMessage(R.string.error_camera_init, R.string.retry, v -> retryCamera());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void retryCamera() {
        hideMessage();
        if (cameraProvider != null) {
            bindCameraUseCases();
        } else if (!cameraStarting) {
            startCamera();
        }
    }

    private void bindCameraUseCases() {
        if (cameraProvider == null) {
            return;
        }

        // Make sure the selected lens really exists on this device
        try {
            boolean hasBack = cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA);
            boolean hasFront = cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA);

            if (!hasBack && !hasFront) {
                showMessage(R.string.error_no_camera_available, R.string.retry, v -> retryCamera());
                return;
            }
            if (lensFacing == CameraSelector.LENS_FACING_BACK && !hasBack) {
                lensFacing = CameraSelector.LENS_FACING_FRONT;
            } else if (lensFacing == CameraSelector.LENS_FACING_FRONT && !hasFront) {
                lensFacing = CameraSelector.LENS_FACING_BACK;
            }

            boolean canSwitch = hasBack && hasFront;
            btnSwitchCamera.setEnabled(canSwitch);
            btnSwitchCamera.setAlpha(canSwitch ? 1f : 0.4f);
        } catch (CameraInfoUnavailableException e) {
            Log.e(TAG, "Could not query cameras", e);
            showMessage(R.string.error_no_camera_available, R.string.retry, v -> retryCamera());
            return;
        }

        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(lensFacing)
                .build();

        preview = new Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        imageCapture = new ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build();

        try {
            cameraProvider.unbindAll();
            camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture);
            hideMessage();
            setupTorchForCurrentCamera();
        } catch (Exception e) {
            Log.e(TAG, "Use case binding failed", e);
            camera = null;
            showMessage(R.string.error_camera_bind, R.string.retry, v -> retryCamera());
        }
    }

    private void switchCamera() {
        if (cameraProvider == null) {
            Toast.makeText(this, R.string.camera_not_ready, Toast.LENGTH_SHORT).show();
            return;
        }
        lensFacing = (lensFacing == CameraSelector.LENS_FACING_BACK)
                ? CameraSelector.LENS_FACING_FRONT
                : CameraSelector.LENS_FACING_BACK;
        torchEnabled = false;
        btnSwitchCamera.animate().rotationBy(180f).setDuration(300).start();
        bindCameraUseCases();
    }

    // =====================================================================
    // Flashlight (torch)
    // =====================================================================

    private void setupTorchForCurrentCamera() {
        removeTorchObserver();
        if (camera == null) {
            return;
        }
        boolean hasFlash = camera.getCameraInfo().hasFlashUnit();
        btnFlash.setAlpha(hasFlash ? 1f : 0.4f);

        if (hasFlash) {
            torchStateLiveData = camera.getCameraInfo().getTorchState();
            torchObserver = state -> {
                boolean on = state != null && state == TorchState.ON;
                torchEnabled = on;
                updateFlashIcon(on);
            };
            torchStateLiveData.observe(this, torchObserver);
        } else {
            torchEnabled = false;
            updateFlashIcon(false);
        }
    }

    private void removeTorchObserver() {
        if (torchStateLiveData != null && torchObserver != null) {
            torchStateLiveData.removeObserver(torchObserver);
        }
        torchStateLiveData = null;
        torchObserver = null;
    }

    private void toggleTorch() {
        if (camera == null) {
            Toast.makeText(this, R.string.camera_not_ready, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!camera.getCameraInfo().hasFlashUnit()) {
            Toast.makeText(this, R.string.flash_not_available, Toast.LENGTH_SHORT).show();
            return;
        }
        camera.getCameraControl().enableTorch(!torchEnabled);
    }

    private void updateFlashIcon(boolean on) {
        btnFlash.setImageResource(on ? R.drawable.ic_flash_on : R.drawable.ic_flash_off);
    }

    // =====================================================================
    // Taking a photo
    // =====================================================================

    @SuppressWarnings("deprecation")
    private void takePhoto() {
        if (imageCapture == null || camera == null) {
            Toast.makeText(this, R.string.camera_not_ready, Toast.LENGTH_SHORT).show();
            return;
        }
        if (isCapturing) {
            return;
        }
        if (!hasStoragePermission()) {
            Toast.makeText(this, R.string.permission_storage_needed, Toast.LENGTH_LONG).show();
            permissionLauncher.launch(requiredPermissions());
            return;
        }

        String name = "IMG_" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
                .format(new Date());

        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/" + APP_FOLDER);
        } else {
            File dir = new File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    APP_FOLDER);
            if (!dir.exists() && !dir.mkdirs()) {
                Toast.makeText(this, R.string.storage_folder_error, Toast.LENGTH_LONG).show();
                return;
            }
            values.put(MediaStore.MediaColumns.DATA, new File(dir, name + ".jpg").getAbsolutePath());
        }

        ImageCapture.Metadata metadata = new ImageCapture.Metadata();
        // Selfies are saved mirrored, exactly like the preview shows them
        metadata.setReversedHorizontal(lensFacing == CameraSelector.LENS_FACING_FRONT);

        ImageCapture.OutputFileOptions outputOptions = new ImageCapture.OutputFileOptions.Builder(
                getContentResolver(),
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values)
                .setMetadata(metadata)
                .build();

        isCapturing = true;
        playShutterEffect();

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults results) {
                        isCapturing = false;
                        Uri savedUri = results.getSavedUri();
                        if (savedUri != null) {
                            lastPhotoUri = savedUri;
                            loadThumbnail(savedUri);
                        }
                        Toast.makeText(MainActivity.this, R.string.photo_saved,
                                Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException exception) {
                        isCapturing = false;
                        Log.e(TAG, "Photo capture failed", exception);
                        Toast.makeText(MainActivity.this,
                                getString(R.string.capture_failed, exception.getMessage()),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void playShutterEffect() {
        viewFlashEffect.animate().cancel();
        viewFlashEffect.setVisibility(View.VISIBLE);
        viewFlashEffect.setAlpha(0.7f);
        viewFlashEffect.animate()
                .alpha(0f)
                .setDuration(200)
                .withEndAction(() -> viewFlashEffect.setVisibility(View.INVISIBLE))
                .start();

        btnCapture.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80)
                .withEndAction(() ->
                        btnCapture.animate().scaleX(1f).scaleY(1f).setDuration(80).start())
                .start();
    }

    /** Keeps the saved photo upright even if the screen orientation is locked. */
    private void setupOrientationListener() {
        orientationListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int orientation) {
                if (orientation == ORIENTATION_UNKNOWN || imageCapture == null) {
                    return;
                }
                int rotation;
                if (orientation >= 45 && orientation < 135) {
                    rotation = Surface.ROTATION_270;
                } else if (orientation >= 135 && orientation < 225) {
                    rotation = Surface.ROTATION_180;
                } else if (orientation >= 225 && orientation < 315) {
                    rotation = Surface.ROTATION_90;
                } else {
                    rotation = Surface.ROTATION_0;
                }
                imageCapture.setTargetRotation(rotation);
            }
        };
    }

    // =====================================================================
    // Thumbnail + opening the latest photo
    // =====================================================================

    private void openLastPhoto() {
        if (lastPhotoUri == null) {
            Toast.makeText(this, R.string.no_photos_yet, Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(lastPhotoUri, "image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show();
        }
    }

    /** Finds the newest photo in Pictures/MyCameraApp and shows it as the thumbnail. */
    private void loadLatestPhoto() {
        backgroundExecutor.execute(() -> {
            Uri uri = queryLatestPhotoUri();
            Bitmap thumb = (uri != null) ? decodeThumbnail(uri, 256) : null;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                lastPhotoUri = uri;
                showThumbnail(thumb);
            });
        });
    }

    private void loadThumbnail(Uri uri) {
        backgroundExecutor.execute(() -> {
            Bitmap thumb = decodeThumbnail(uri, 256);
            runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()) {
                    showThumbnail(thumb);
                }
            });
        });
    }

    @SuppressWarnings("deprecation")
    @Nullable
    private Uri queryLatestPhotoUri() {
        String selection;
        String[] selectionArgs;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            selection = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
            selectionArgs = new String[]{Environment.DIRECTORY_PICTURES + "/" + APP_FOLDER + "%"};
        } else {
            selection = MediaStore.Images.Media.DATA + " LIKE ?";
            selectionArgs = new String[]{
                    "%/" + Environment.DIRECTORY_PICTURES + "/" + APP_FOLDER + "/%"};
        }

        try (Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID},
                selection,
                selectionArgs,
                MediaStore.Images.Media.DATE_ADDED + " DESC, " + MediaStore.Images.Media._ID + " DESC")) {
            if (cursor != null && cursor.moveToFirst()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not query latest photo", e);
        }
        return null;
    }

    /** Decodes a small, correctly rotated, square (centre-cropped) bitmap for the thumbnail. */
    @Nullable
    private Bitmap decodeThumbnail(Uri uri, int targetSize) {
        try {
            // 1) read the image size only
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) {
                    return null;
                }
                BitmapFactory.decodeStream(in, null, bounds);
            }

            int sample = 1;
            while ((bounds.outWidth / (sample * 2)) >= targetSize
                    && (bounds.outHeight / (sample * 2)) >= targetSize) {
                sample *= 2;
            }

            // 2) decode a down-sampled bitmap
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap bitmap;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) {
                    return null;
                }
                bitmap = BitmapFactory.decodeStream(in, null, opts);
            }
            if (bitmap == null) {
                return null;
            }

            // 3) apply the EXIF rotation
            int orientation = ExifInterface.ORIENTATION_NORMAL;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in != null) {
                    orientation = new ExifInterface(in).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                }
            }
            Matrix matrix = new Matrix();
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    matrix.postRotate(90);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    matrix.postRotate(180);
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    matrix.postRotate(270);
                    break;
                case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
                    matrix.postScale(-1, 1);
                    break;
                case ExifInterface.ORIENTATION_FLIP_VERTICAL:
                    matrix.postScale(1, -1);
                    break;
                case ExifInterface.ORIENTATION_TRANSPOSE:
                    matrix.postRotate(90);
                    matrix.postScale(-1, 1);
                    break;
                case ExifInterface.ORIENTATION_TRANSVERSE:
                    matrix.postRotate(270);
                    matrix.postScale(-1, 1);
                    break;
                default:
                    break;
            }
            Bitmap rotated = matrix.isIdentity()
                    ? bitmap
                    : Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                    matrix, true);

            // 4) centre-crop to a square
            int side = Math.min(rotated.getWidth(), rotated.getHeight());
            return Bitmap.createBitmap(rotated,
                    (rotated.getWidth() - side) / 2,
                    (rotated.getHeight() - side) / 2,
                    side, side);
        } catch (Exception e) {
            Log.w(TAG, "Could not decode thumbnail", e);
            return null;
        }
    }

    private void showThumbnail(@Nullable Bitmap bitmap) {
        if (bitmap == null) {
            int pad = dp(16);
            imgThumbnail.setPadding(pad, pad, pad, pad);
            imgThumbnail.setImageResource(R.drawable.ic_gallery);
            return;
        }
        RoundedBitmapDrawable drawable =
                RoundedBitmapDrawableFactory.create(getResources(), bitmap);
        drawable.setCircular(true);
        int pad = dp(3);
        imgThumbnail.setPadding(pad, pad, pad, pad);
        imgThumbnail.setImageDrawable(drawable);
    }

    // =====================================================================
    // Message overlay (errors / permission)
    // =====================================================================

    private void showMessage(@StringRes int messageRes,
                             @StringRes int actionLabelRes,
                             @Nullable View.OnClickListener action) {
        tvMessage.setText(messageRes);
        if (action != null && actionLabelRes != 0) {
            btnMessageAction.setText(actionLabelRes);
            btnMessageAction.setOnClickListener(action);
            btnMessageAction.setVisibility(View.VISIBLE);
        } else {
            btnMessageAction.setVisibility(View.GONE);
        }
        layoutMessage.setVisibility(View.VISIBLE);
        btnCapture.setEnabled(false);
        btnCapture.setAlpha(0.4f);
    }

    private void hideMessage() {
        layoutMessage.setVisibility(View.GONE);
        btnCapture.setEnabled(true);
        btnCapture.setAlpha(1f);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
